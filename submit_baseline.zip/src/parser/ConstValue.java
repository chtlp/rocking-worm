package parser;

public abstract class ConstValue extends Value {
}