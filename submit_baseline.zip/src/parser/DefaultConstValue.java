package parser;

public class DefaultConstValue extends ConstValue{
	public DefaultConstValue() {};
}
