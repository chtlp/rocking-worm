package parser;

public class TimeConstValue extends ConstValue{
	public String string;
	public TimeConstValue(int p, String s) {pos=p; string=s;}
}
