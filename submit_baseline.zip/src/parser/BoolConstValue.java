package parser;

public class BoolConstValue extends ConstValue{
	public boolean b;
	public BoolConstValue(int p, boolean bb) {pos=p; b=bb;}
}
