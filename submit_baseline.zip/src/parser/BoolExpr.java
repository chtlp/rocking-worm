package parser;

abstract public class BoolExpr extends Absyn{
}
