package parser;

public class BracketValue extends Value{
	public Value value;
	public BracketValue(int p, Value v) {pos=p; value=v;}
}
