package parser;

public class DbName extends Absyn {
   public String name;
   public DbName(int p, String s) {pos=p; name=s;}
}