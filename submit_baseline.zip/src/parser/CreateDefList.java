package parser;

public class CreateDefList {
	public CreateDef head;
	public CreateDefList tail;
	public CreateDefList(CreateDef h, CreateDefList t) {head=h; tail=t;}
}
