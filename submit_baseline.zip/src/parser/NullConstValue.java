package parser;

public class NullConstValue extends ConstValue{
	public NullConstValue(int p) {pos=p;}
}
