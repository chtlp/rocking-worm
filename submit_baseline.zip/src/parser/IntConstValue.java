package parser;

public class IntConstValue extends ConstValue{
	public int integer;
	public IntConstValue(int p, int i) {pos=p; integer=i;} 
}
