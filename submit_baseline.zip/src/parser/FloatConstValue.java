package parser;

public class FloatConstValue extends ConstValue{
	public float f;
	public FloatConstValue(int p, float ff) {pos=p; f=ff;}
}
