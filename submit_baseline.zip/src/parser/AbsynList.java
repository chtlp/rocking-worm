package parser;
public class AbsynList {
   public Absyn head;
   public AbsynList tail;
   public AbsynList(Absyn h, AbsynList t) {head=h; tail=t;}
}