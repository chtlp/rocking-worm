package parser;
abstract public class Absyn {
  public int pos;
  public static final boolean DEBUG = false; 
}