package parser;

public class IsAuto {
	public boolean isAuto;
	public IsAuto(boolean b) {isAuto=b;}
}
