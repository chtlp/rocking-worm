package parser;
public class DropTable extends Absyn {
   public NameList nList;
   public DropTable(int p, NameList nl) {pos=p; nList=nl;}
}
