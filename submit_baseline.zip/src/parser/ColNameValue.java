package parser;

public class ColNameValue extends Value{
	public ColName colName;
	public ColNameValue(int p, ColName c) {pos=p; colName=c;}
}
