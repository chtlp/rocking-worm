package transaction;

public class DeadlockException extends Exception {
	private static final long serialVersionUID = 3993282929224182216L;
}
