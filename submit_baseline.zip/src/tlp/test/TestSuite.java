package tlp.test;

import static org.junit.runner.JUnitCore.runClasses;
public class TestSuite {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		runClasses(TestSortPlan.class);
	}

}
