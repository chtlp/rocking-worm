package index;

public class IndexException extends RuntimeException {

	private static final long serialVersionUID = -8601791993435363241L;
	
	public IndexException() {
		super("Error about fatworm index");
	}

}
