package plan;

import transaction.Transaction;

/**
 * A responsive plan for specific query.
 */
public abstract class Plan {
	Transaction tr;
	
}
