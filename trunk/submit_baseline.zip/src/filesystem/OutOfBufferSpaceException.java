package filesystem;

public class OutOfBufferSpaceException extends RuntimeException {

	private static final long serialVersionUID = -4612958876548591321L;

}
