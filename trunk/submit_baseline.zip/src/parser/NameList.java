package parser;

public class NameList {
	public String head;
	public NameList tail;
	public NameList(String h, NameList t) {head=h; tail=t;}
}
