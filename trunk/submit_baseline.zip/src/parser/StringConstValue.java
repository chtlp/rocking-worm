package parser;

public class StringConstValue extends ConstValue{
	public String string;
	public StringConstValue(int p, String s) {pos=p; string=s;}
}
