package parser;
public class UseDatabase extends Absyn {
   public String dbName;
   public UseDatabase(int p, String s) {pos=p; dbName=s;}
}
