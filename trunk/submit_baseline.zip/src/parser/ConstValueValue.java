package parser;

public class ConstValueValue extends Value{
	public ConstValue constValue;
	public ConstValueValue(int p, ConstValue c) {pos=p; constValue=c;}
}
