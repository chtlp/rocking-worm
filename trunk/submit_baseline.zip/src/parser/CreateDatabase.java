package parser;
public class CreateDatabase extends Absyn {
   public String dbName;
   public CreateDatabase(int p, String s) {pos=p; dbName=s;}
}
