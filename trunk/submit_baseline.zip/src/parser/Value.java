package parser;

abstract public class Value extends Absyn{
}
